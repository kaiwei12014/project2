# Deep-Trading
Algorithmic trading with deep learning experiments.
Now released part one - simple time series forecasting.
I plan to implement more sophisticated algorithms and their ensembles with different features, check their performance, train a trading strategy and go live.
